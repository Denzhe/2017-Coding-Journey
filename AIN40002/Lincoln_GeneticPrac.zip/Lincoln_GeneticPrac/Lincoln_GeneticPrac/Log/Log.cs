﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lincoln_GeneticPrac
{
  public static class Log
    {
        private static string path = "Log.txt";

        public static void Write(string text)
        {
            CheckFile();

            using (StreamWriter file = File.AppendText(path))
            {
                file.Write(text);
            }
        }

        public static void WriteLine(string text = "")
        {
            CheckFile();
            using (StreamWriter file = File.AppendText(path))
            {
                file.WriteLine(text);
            }
        }

        private static void CheckFile()
        {
            if (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine("Genetic Algorithm");
                }
            }
        }

      
    }
}
